﻿namespace Simulador_de_Credito_MA
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtRUT = new System.Windows.Forms.TextBox();
            this.txtDV = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.lblRUT = new System.Windows.Forms.Label();
            this.lblDV = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblApellido1 = new System.Windows.Forms.Label();
            this.lblApellido2 = new System.Windows.Forms.Label();
            this.lblFechaNac = new System.Windows.Forms.Label();
            this.lblProfesion = new System.Windows.Forms.Label();
            this.lblSueldo = new System.Windows.Forms.Label();
            this.dateFecha = new System.Windows.Forms.DateTimePicker();
            this.boxProfesion = new System.Windows.Forms.ComboBox();
            this.txtApellido2 = new System.Windows.Forms.TextBox();
            this.txtApellido1 = new System.Windows.Forms.TextBox();
            this.txtSueldo = new System.Windows.Forms.TextBox();
            this.butRegistrar = new System.Windows.Forms.Button();
            this.lblRegistro = new System.Windows.Forms.Label();
            this.lblMensaje = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblMensajee = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtRUT
            // 
            this.txtRUT.BackColor = System.Drawing.SystemColors.Info;
            this.txtRUT.Location = new System.Drawing.Point(93, 201);
            this.txtRUT.Margin = new System.Windows.Forms.Padding(4);
            this.txtRUT.MaxLength = 9;
            this.txtRUT.Name = "txtRUT";
            this.txtRUT.Size = new System.Drawing.Size(384, 22);
            this.txtRUT.TabIndex = 0;
            this.txtRUT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRUT_KeyPress);
            // 
            // txtDV
            // 
            this.txtDV.BackColor = System.Drawing.SystemColors.Info;
            this.txtDV.Location = new System.Drawing.Point(503, 202);
            this.txtDV.Margin = new System.Windows.Forms.Padding(4);
            this.txtDV.MaxLength = 1;
            this.txtDV.Name = "txtDV";
            this.txtDV.Size = new System.Drawing.Size(89, 22);
            this.txtDV.TabIndex = 1;
            this.txtDV.TextChanged += new System.EventHandler(this.txtDV_TextChanged);
            this.txtDV.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDV_KeyPress);
            // 
            // txtNombre
            // 
            this.txtNombre.BackColor = System.Drawing.SystemColors.Info;
            this.txtNombre.Location = new System.Drawing.Point(93, 257);
            this.txtNombre.Margin = new System.Windows.Forms.Padding(4);
            this.txtNombre.MaxLength = 100;
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(499, 22);
            this.txtNombre.TabIndex = 2;
            // 
            // lblRUT
            // 
            this.lblRUT.AutoSize = true;
            this.lblRUT.Font = new System.Drawing.Font("Nirmala UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRUT.Location = new System.Drawing.Point(93, 181);
            this.lblRUT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRUT.Name = "lblRUT";
            this.lblRUT.Size = new System.Drawing.Size(32, 17);
            this.lblRUT.TabIndex = 3;
            this.lblRUT.Text = "RUT";
            // 
            // lblDV
            // 
            this.lblDV.AutoSize = true;
            this.lblDV.Location = new System.Drawing.Point(484, 205);
            this.lblDV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDV.Name = "lblDV";
            this.lblDV.Size = new System.Drawing.Size(11, 16);
            this.lblDV.TabIndex = 4;
            this.lblDV.Text = "-";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Nirmala UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(93, 237);
            this.lblNombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(57, 17);
            this.lblNombre.TabIndex = 5;
            this.lblNombre.Text = "Nombre";
            // 
            // lblApellido1
            // 
            this.lblApellido1.AutoSize = true;
            this.lblApellido1.Font = new System.Drawing.Font("Nirmala UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellido1.Location = new System.Drawing.Point(93, 292);
            this.lblApellido1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblApellido1.Name = "lblApellido1";
            this.lblApellido1.Size = new System.Drawing.Size(67, 17);
            this.lblApellido1.TabIndex = 6;
            this.lblApellido1.Text = "Apellido 1";
            // 
            // lblApellido2
            // 
            this.lblApellido2.AutoSize = true;
            this.lblApellido2.Font = new System.Drawing.Font("Nirmala UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellido2.Location = new System.Drawing.Point(93, 351);
            this.lblApellido2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblApellido2.Name = "lblApellido2";
            this.lblApellido2.Size = new System.Drawing.Size(67, 17);
            this.lblApellido2.TabIndex = 7;
            this.lblApellido2.Text = "Apellido 2";
            // 
            // lblFechaNac
            // 
            this.lblFechaNac.AutoSize = true;
            this.lblFechaNac.Font = new System.Drawing.Font("Nirmala UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaNac.Location = new System.Drawing.Point(93, 410);
            this.lblFechaNac.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFechaNac.Name = "lblFechaNac";
            this.lblFechaNac.Size = new System.Drawing.Size(130, 17);
            this.lblFechaNac.TabIndex = 8;
            this.lblFechaNac.Text = "Fecha de Nacimiento";
            // 
            // lblProfesion
            // 
            this.lblProfesion.AutoSize = true;
            this.lblProfesion.Font = new System.Drawing.Font("Nirmala UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProfesion.Location = new System.Drawing.Point(93, 469);
            this.lblProfesion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProfesion.Name = "lblProfesion";
            this.lblProfesion.Size = new System.Drawing.Size(63, 17);
            this.lblProfesion.TabIndex = 9;
            this.lblProfesion.Text = "Profesión";
            // 
            // lblSueldo
            // 
            this.lblSueldo.AutoSize = true;
            this.lblSueldo.Font = new System.Drawing.Font("Nirmala UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSueldo.Location = new System.Drawing.Point(93, 533);
            this.lblSueldo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSueldo.Name = "lblSueldo";
            this.lblSueldo.Size = new System.Drawing.Size(95, 17);
            this.lblSueldo.TabIndex = 10;
            this.lblSueldo.Text = "Sueldo Liquido";
            // 
            // dateFecha
            // 
            this.dateFecha.CalendarForeColor = System.Drawing.SystemColors.WindowFrame;
            this.dateFecha.CalendarTrailingForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dateFecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateFecha.Location = new System.Drawing.Point(96, 430);
            this.dateFecha.Margin = new System.Windows.Forms.Padding(4);
            this.dateFecha.Name = "dateFecha";
            this.dateFecha.Size = new System.Drawing.Size(496, 22);
            this.dateFecha.TabIndex = 11;
            // 
            // boxProfesion
            // 
            this.boxProfesion.BackColor = System.Drawing.SystemColors.Info;
            this.boxProfesion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.boxProfesion.ForeColor = System.Drawing.SystemColors.InfoText;
            this.boxProfesion.FormattingEnabled = true;
            this.boxProfesion.Items.AddRange(new object[] {
            "MEDICO",
            "INGENIERO",
            "ABOGADO",
            "ENFERMERO/A",
            "ADMINISTRADOR/A",
            "MILITAR",
            "POLICIA",
            "COSMETOLOGO/A",
            "INDEPENDIENTE",
            "ESTUDIANTE",
            "N/A"});
            this.boxProfesion.Location = new System.Drawing.Point(93, 489);
            this.boxProfesion.Margin = new System.Windows.Forms.Padding(4);
            this.boxProfesion.Name = "boxProfesion";
            this.boxProfesion.Size = new System.Drawing.Size(499, 24);
            this.boxProfesion.TabIndex = 12;
            // 
            // txtApellido2
            // 
            this.txtApellido2.BackColor = System.Drawing.SystemColors.Info;
            this.txtApellido2.Location = new System.Drawing.Point(93, 371);
            this.txtApellido2.Margin = new System.Windows.Forms.Padding(4);
            this.txtApellido2.Name = "txtApellido2";
            this.txtApellido2.Size = new System.Drawing.Size(499, 22);
            this.txtApellido2.TabIndex = 13;
            // 
            // txtApellido1
            // 
            this.txtApellido1.BackColor = System.Drawing.SystemColors.Info;
            this.txtApellido1.Location = new System.Drawing.Point(93, 312);
            this.txtApellido1.Margin = new System.Windows.Forms.Padding(4);
            this.txtApellido1.Name = "txtApellido1";
            this.txtApellido1.Size = new System.Drawing.Size(499, 22);
            this.txtApellido1.TabIndex = 14;
            // 
            // txtSueldo
            // 
            this.txtSueldo.BackColor = System.Drawing.SystemColors.Info;
            this.txtSueldo.Location = new System.Drawing.Point(93, 553);
            this.txtSueldo.Margin = new System.Windows.Forms.Padding(4);
            this.txtSueldo.Name = "txtSueldo";
            this.txtSueldo.Size = new System.Drawing.Size(499, 22);
            this.txtSueldo.TabIndex = 15;
            // 
            // butRegistrar
            // 
            this.butRegistrar.Location = new System.Drawing.Point(492, 599);
            this.butRegistrar.Margin = new System.Windows.Forms.Padding(4);
            this.butRegistrar.Name = "butRegistrar";
            this.butRegistrar.Size = new System.Drawing.Size(100, 28);
            this.butRegistrar.TabIndex = 16;
            this.butRegistrar.Text = "Registrar";
            this.butRegistrar.UseVisualStyleBackColor = true;
            this.butRegistrar.Click += new System.EventHandler(this.butContinuar_Click);
            // 
            // lblRegistro
            // 
            this.lblRegistro.AutoSize = true;
            this.lblRegistro.Font = new System.Drawing.Font("Nirmala UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegistro.Location = new System.Drawing.Point(48, 18);
            this.lblRegistro.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRegistro.Name = "lblRegistro";
            this.lblRegistro.Size = new System.Drawing.Size(156, 17);
            this.lblRegistro.TabIndex = 17;
            this.lblRegistro.Text = " REGISTRO DE CLIENTES";
            // 
            // lblMensaje
            // 
            this.lblMensaje.AutoSize = true;
            this.lblMensaje.Location = new System.Drawing.Point(12, 192);
            this.lblMensaje.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMensaje.Name = "lblMensaje";
            this.lblMensaje.Size = new System.Drawing.Size(0, 16);
            this.lblMensaje.TabIndex = 19;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Menu;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.dataGridView1.Location = new System.Drawing.Point(51, 48);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(589, 119);
            this.dataGridView1.TabIndex = 20;
            // 
            // lblMensajee
            // 
            this.lblMensajee.AutoSize = true;
            this.lblMensajee.Font = new System.Drawing.Font("Nirmala UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMensajee.ForeColor = System.Drawing.SystemColors.Window;
            this.lblMensajee.Location = new System.Drawing.Point(500, 181);
            this.lblMensajee.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMensajee.Name = "lblMensajee";
            this.lblMensajee.Size = new System.Drawing.Size(11, 17);
            this.lblMensajee.TabIndex = 21;
            this.lblMensajee.Text = ".";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(690, 642);
            this.Controls.Add(this.lblMensajee);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblMensaje);
            this.Controls.Add(this.lblRegistro);
            this.Controls.Add(this.butRegistrar);
            this.Controls.Add(this.txtSueldo);
            this.Controls.Add(this.txtApellido1);
            this.Controls.Add(this.txtApellido2);
            this.Controls.Add(this.boxProfesion);
            this.Controls.Add(this.dateFecha);
            this.Controls.Add(this.lblSueldo);
            this.Controls.Add(this.lblProfesion);
            this.Controls.Add(this.lblFechaNac);
            this.Controls.Add(this.lblApellido2);
            this.Controls.Add(this.lblApellido1);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.lblDV);
            this.Controls.Add(this.lblRUT);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.txtDV);
            this.Controls.Add(this.txtRUT);
            this.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Simulador de Credito v.1.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtRUT;
        private System.Windows.Forms.TextBox txtDV;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lblRUT;
        private System.Windows.Forms.Label lblDV;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblApellido1;
        private System.Windows.Forms.Label lblApellido2;
        private System.Windows.Forms.Label lblFechaNac;
        private System.Windows.Forms.Label lblProfesion;
        private System.Windows.Forms.Label lblSueldo;
        private System.Windows.Forms.DateTimePicker dateFecha;
        private System.Windows.Forms.ComboBox boxProfesion;
        private System.Windows.Forms.TextBox txtApellido2;
        private System.Windows.Forms.TextBox txtApellido1;
        private System.Windows.Forms.TextBox txtSueldo;
        private System.Windows.Forms.Button butRegistrar;
        private System.Windows.Forms.Label lblRegistro;
        private System.Windows.Forms.Label lblMensaje;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblMensajee;
    }
}

