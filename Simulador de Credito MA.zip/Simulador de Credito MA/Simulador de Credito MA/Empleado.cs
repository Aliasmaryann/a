﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simulador_de_Credito_MA
{
    public class Empleado //Esta implicito que es publica igual
    {

        public int RUT { get; set; } // prop y luego tab, tab
        public string DV { get; set; }
        public string nombre { get; set; }
        public string apellido1 { get; set; }
        public string apellido2 { get; set; }
        public int telefono { get; set; }
        public int codigo_cargo { get; set; }

        //Metodo consultar sueldo
        public int ConsultaSueldo()
        {

            return 0;
        }

    }
}
