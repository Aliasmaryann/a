﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Net.Mime.MediaTypeNames;

namespace Simulador_de_Credito_MA
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void butConsultar_Click(object sender, EventArgs e)
        {

            string rut = cbxUsuario.SelectedValue.ToString();
            string tipo_credito = cbxTipoCredito.SelectedValue.ToString();
            string monto = txtMonto.Text;
            string plazos = cbxPlazos.Text;
            double tasa_i = ObtenerTasaInteresDesdeBD(tipo_credito);

            // Autenticacion SQL Server
            string strConexionSQL = "Server=BGLABI00716\\BUSSQL;Database=simucredito;User Id=sa;Password=Aiep.2022;";

            try
                {
                   
                    // Mostrar resultado de ValidarEdad
                    MostrarResultado("ValidarEdad", rut, monto, tipo_credito, plazos, strConexionSQL);

                    // Mostrar resultado de ValidarCredito
                    MostrarResultado("ValidarCredito", rut, monto, tipo_credito, null, strConexionSQL);

                    // Calcular y mostrar cuotas mensuales
                    MostrarCuota(monto,plazos, tasa_i.ToString());

                // Mostrar mensaje de éxito después de ejecutar ambos procedimientos almacenados
                MessageBox.Show("Cumple los requisitos para solicitar el crédito");
            }
            catch (Exception ex)
            {
                // En caso de algún error, mostrar el error
                MessageBox.Show($"Error: {ex.Message}", "Error");
            }

        }

        static double ObtenerTasaInteresDesdeBD(string tipo_credito)
        {
            double tasaInteres = 0.0;

            // Cadena de conexión a la base de datos
            string strConexionSQL = "Server=BGLABI00716\\BUSSQL;Database=simucredito;User Id=sa;Password=Aiep.2022;";

            using (SqlConnection connection = new SqlConnection(strConexionSQL))
            {
                connection.Open();

                // Consulta SQL para obtener la tasa de interés
                string query = "SELECT TASA_I FROM Credito WHERE NOMBRE = '" + tipo_credito + "'";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Ejecutar la consulta y obtener el resultado
                    object result = command.ExecuteScalar();

                    // Verificar si el resultado es válido
                    if (result != null && result != DBNull.Value)
                    {
                        tasaInteres = Convert.ToDouble(result);
                    }
                }
            }

            return tasaInteres;
        }

        private void MostrarCuota(string monto, string plazos, string tasaInteres)
        {
            double montoPrestamo = Double.Parse(monto);
            double tasa_Interes = Double.Parse(tasaInteres);
            int plazoA = int.Parse(plazos);

            // Calcular la cuota de amortización constante
            double cuota = CalcularCuotaAmortizacion(montoPrestamo, tasa_Interes, plazoA);

            // Mostrar el resultado
            MessageBox.Show("Cuota de amortización mensual: " + cuota.ToString("C"));


        }

        static double CalcularCuotaAmortizacion(double montoPrestamo, double tasa_Interes, int plazoA)
        {
            
                // Convertir la tasa de interés anual a periódica
                double tasaInteresPeriodica = tasa_Interes / 12;

                // Calcular el número total de pagos
                int numeroPagos = plazoA * 12;

                // Calcular la cuota de amortización constante
                double cuota = (tasaInteresPeriodica * montoPrestamo) / (1 - Math.Pow(1 + tasaInteresPeriodica, -numeroPagos));

                return cuota;
           
        }

        private void MostrarResultado(string storedProcedure, string rut, string monto, string tipoCredito, string plazos, string connectionString)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                using (SqlCommand cmd = new SqlCommand(storedProcedure, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@rut_cliente", rut);
                    cmd.Parameters.AddWithValue("@monto_solicitado", monto);
                    cmd.Parameters.AddWithValue("@Codigo_Credito", tipoCredito);

                    if (plazos != null)
                    {
                        cmd.Parameters.AddWithValue("@plazo", plazos);
                    }

                    SqlParameter codRetornoParam = new SqlParameter("@cod_retorno", SqlDbType.Int);
                    codRetornoParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(codRetornoParam);

                    SqlParameter mensajeParam = new SqlParameter("@Mensaje", SqlDbType.NVarChar, -1);
                    mensajeParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(mensajeParam);

                    cmd.ExecuteNonQuery();

                    //int codRetornoValue = Convert.ToInt32(codRetornoParam.Value);
                    string v = mensajeParam.Value.ToString();
                    string mensajeValue = v;

                    // Mostrar resultado en MessageBox          \nCódigo de retorno: {codRetornoValue}
                    MessageBox.Show($"Resultado de {storedProcedure}:\nMensaje: {mensajeValue}", "Resultado");
                }
            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            try
            {
                // Poblar grilla

                // Definir string de conexion y el comando sql

                // Autenticacion SQL Server
                string strConexionSQL = "Server=BGLABI00716\\BUSSQL;Database=simucredito;User Id=sa;Password=Aiep.2022;";

                // Instruccion SQL
                string comandoSQL = "select * from Credito";


                // Crear los objetos para la conexion a la BD
                SqlConnection con = new SqlConnection(strConexionSQL);
                DataTable tbTipo = new DataTable();

                // abrir conexion y ejecutar instrucicon sql
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(comandoSQL, con);

                da.Fill(tbTipo);



                // poblar el combobox con el resultado del select 
                dataGridView1.DataSource = tbTipo;

                // cerra la conexion
                con.Close();
            }
            catch (Exception es)
            {
                MessageBox.Show(es.Message);
            }

            try
            {
                //COMBO BOX CREDITOS

                // Autenticacion SQL Server
                string strConexionSQL = "Server=BGLABI00716\\BUSSQL;Database=simucredito;User Id=sa;Password=Aiep.2022;";

                // Instruccion SQL
                string comandoSQL = "select CODIGO, NOMBRE  from Credito";


                // Crear los objetos para la conexion a la BD
                SqlConnection con = new SqlConnection(strConexionSQL);
                DataTable tbTipo = new DataTable();

                // abrir conexion y ejecutar instraucicon sql
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(comandoSQL, con);

                da.Fill(tbTipo);

                // configuracion del combox 
                cbxTipoCredito.DisplayMember = "NOMBRE";
                cbxTipoCredito.ValueMember = "CODIGO";

                // poblar el combobox con el resultado del select 
                cbxTipoCredito.DataSource = tbTipo;

                // cerra la conexion
                con.Close();
            }
            catch (Exception es)
            {
                MessageBox.Show(es.Message);
            }
            // Fin 
            // Inicio
            try
            {
                //COMBO BOX RUT

                // Autenticacion SQL Server
                string strConexionSQL = "Server=BGLABI00716\\BUSSQL;Database=simucredito;User Id=sa;Password=Aiep.2022;";

                // Instruccion SQL
                string comandoSQL = "select RUT, NOMBRE  from cliente";


                // Crear los objetos para la conexion a la BD
                SqlConnection con = new SqlConnection(strConexionSQL);
                DataTable tbTipo = new DataTable();

                // abrir conexion y ejecutar instraucicon sql
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(comandoSQL, con);

                da.Fill(tbTipo);

                // configuracion del combox 
                cbxUsuario.DisplayMember = "RUT";
                cbxUsuario.ValueMember = "RUT";

                // poblar el combobox con el resultado del select 
                cbxUsuario.DataSource = tbTipo;

                // cerra la conexion
                con.Close();
            }
            catch (Exception es)
            {
                MessageBox.Show(es.Message);
            }
            // Fin 
            try
            {
                //COMBO BOX PLAZOS

                // Autenticacion SQL Server
                string strConexionSQL = "Server=BGLABI00716\\BUSSQL;Database=simucredito;User Id=sa;Password=Aiep.2022;";

                // Instruccion SQL
                string comandoSQL = "select DISTINCT PLAZO_MIN,PLAZO_MAX  from Credito";


                // Crear los objetos para la conexion a la BD
                SqlConnection con = new SqlConnection(strConexionSQL);
                DataTable tbTipo = new DataTable();

                // abrir conexion y ejecutar instraucicon sql
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(comandoSQL, con);

                da.Fill(tbTipo);

                var plazos = new List<int>();

                foreach (DataRow row in tbTipo.Rows)
                {
                    int min = Convert.ToInt32(row["PLAZO_MIN"]);
                    int max = Convert.ToInt32(row["PLAZO_MAX"]);

                    // Agregar todos los números entre min y max (inclusive) a la lista
                    for (int i = min; i <= max; i++)
                    {
                        plazos.Add(i);
                    }
                }

                // Poblar el combobox con la lista de plazos
                cbxPlazos.DataSource = plazos;


                // cerra la conexion
                con.Close();
            }
            catch (Exception es)
            {
                MessageBox.Show(es.Message);
            }
            // Fin 

        }
        

    }
}
