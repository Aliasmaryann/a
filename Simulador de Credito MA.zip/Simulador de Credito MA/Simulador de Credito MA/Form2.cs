﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Simulador_de_Credito_MA
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            // Capturar desde las cajas de textos los valores
            string NOMBRE = txtNombre.Text;
            string TASA = txtTasa.Text;
            string EDAD = txtEdad.Text;
            string MONTO_MINIMO = txtMontoMin.Text;
            string MONTO_MAXIMO = txtMontoMax.Text;
            string SUELDO_MINIMO = txtSueldo.Text;
            string PLAZO_MAX= txtPlazoMax.Text;
            string PLAZO_MIN = txtPlazoMin.Text;


            // Definir string de conexion y el comando sal

            // Autenticacion Windows
            //string strWindows = "server=DESKTOP-DEKF1IC;database=sistema_remuneracion;Integrated Security=True";
            // Autenticacion SQL Server
            string strConexionSQL = "Server=BGLABI00716\\BUSSQL;Database=simucredito;User Id=sa;Password=Aiep.2022;";

            // Instruccion SQL
            string comandoSQL = "insert Credito (NOMBRE,TASA_I,EDAD_MAX,MONTO_MIN,MONTO_MAX,SUELDO_MIN,PLAZO_MIN,PLAZO_MAX) values ('" + NOMBRE + "'," + TASA + "," + EDAD + "," + MONTO_MINIMO + "," + MONTO_MAXIMO + "," + SUELDO_MINIMO + "," + PLAZO_MIN + "," + PLAZO_MAX + ")";

            // Crear los objetos para la conexion a la BD
            SqlDataAdapter da;
            SqlConnection con = new SqlConnection(strConexionSQL);
            try
            {
                // Abrir la conexion 
                con.Open();

                // Ejecutar la instrucicon SQL
                da = new SqlDataAdapter();
                da.InsertCommand = new SqlCommand(comandoSQL, con);
                da.InsertCommand.ExecuteNonQuery();

                // Cerra la conexion
                con.Close();

                // Actualizar la grilla
                ActualizarGrilla();

                // Mostrar mensaje de exito
                MessageBox.Show("Registro grabado exitosamente.");

            }
            catch (Exception ex)
            {
                // en caso de algun error, mostrar el error
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                    con.Close();
            }
            // Fin 
        }
        private void ActualizarGrilla()
        {
            try
            {
                // Poblar grilla
                string strConexionSQL = "Server=BGLABI00716\\BUSSQL;Database=simucredito;User Id=sa;Password=Aiep.2022;";
                string comandoSQL = "select * from Credito";
                SqlConnection con = new SqlConnection(strConexionSQL);
                DataTable tbTipo = new DataTable();

                // Abrir conexión y ejecutar instrucción SQL
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(comandoSQL, con);
                da.Fill(tbTipo);

                // Poblar la grilla con el resultado del select 
                dataGridView1.DataSource = tbTipo;

                // Cerrar la conexión
                con.Close();
            }
            catch (Exception es)
            {
                MessageBox.Show(es.Message);
            }
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            // Inicio
            try
            {
                // Poblar grilla
                // Definir string de conexion y el comando sql
                // Autenticacion Windows
                //string strWindows = "server=DESKTOP-DEKF1IC;database=sistema_remuneracion;Integrated Security=True";
                // Autenticacion SQL Server
                string strConexionSQL = "Server=BGLABI00716\\BUSSQL;Database=simucredito;User Id=sa;Password=Aiep.2022;";

                // Instruccion SQL
                string comandoSQL = "select * from Credito";


                // Crear los objetos para la conexion a la BD
                SqlConnection con = new SqlConnection(strConexionSQL);
                DataTable tbTipo = new DataTable();

                // abrir conexion y ejecutar instrucicon sql
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(comandoSQL, con);

                da.Fill(tbTipo);

 

                // poblar el combobox con el resultado del select 
                dataGridView1.DataSource = tbTipo;

                // cerra la conexion
                con.Close();
            }
            catch (Exception es)
            {
                MessageBox.Show(es.Message);
            }
            // Fin 
        }
    }
}
