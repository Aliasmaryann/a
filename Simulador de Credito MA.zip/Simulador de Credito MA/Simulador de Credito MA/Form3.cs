﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Simulador_de_Credito_MA
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OcultarPresentacion();
            Form1 f = new Form1();
            f.MdiParent = this; //this es de formulario 3
            f.Show();
        }

        private void tiposDeCreditosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OcultarPresentacion();
            Form2 f = new Form2();
            f.MdiParent = this; //this es de formulario 3
            f.Show();
        }


        private void solicitarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OcultarPresentacion();
            Form5 f = new Form5();
            f.MdiParent = this; //this es de formulario 3
            f.Show();
        }
        private void OcultarPresentacion()
        {
            // Esconder o enviar al fondo el cuadro de texto
            lblPresentacion.Visible = false;
            // o
            // textBoxPresentacion.SendToBack();
        }

        private void AcercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lblPresentacion.Visible = true;
        }
    }
}
