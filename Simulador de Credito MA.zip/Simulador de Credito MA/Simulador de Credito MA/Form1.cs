﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;

namespace Simulador_de_Credito_MA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtRUT_KeyPress(object sender, KeyPressEventArgs e) //sender es el objeto
        {       // ! sinifica no
            if (!(char.IsNumber(e.KeyChar)) && (e.KeyChar != (char)Keys.Back))
            {
                e.Handled = true;
                return;
            }
        }

        private void txtDV_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDV_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)) && (e.KeyChar != (char)Keys.Back) && (e.KeyChar != 'K') && (e.KeyChar != 'k'))
            {
                e.Handled = true;
                return;
            }
        }

        public static string Digito(int rut)
        {
            int suma = 0;
            int multiplicador = 1;
            while (rut != 0)
            {
                multiplicador++;
                if (multiplicador == 8)
                    multiplicador = 2;
                suma += (rut % 10) * multiplicador;
                rut = rut / 10;
            }
            suma = 11 - (suma % 11);
            if (suma == 11)
            {
                return "0";
            }
            else if (suma == 10)
            {
                return "K";
            }
            else
            {
                return suma.ToString();
            }
        }

        private void butContinuar_Click(object sender, EventArgs e)
        {
            //validar el ingreso del rut
            int RUT = int.Parse(txtRUT.Text);
            string DV = Digito(RUT);
            string DVIngresado = txtDV.Text;

            if (DV != DVIngresado)
            {
                lblMensajee.ForeColor = Color.Red;
                lblMensajee.Text = "RUT INVALIDO";
                MessageBox.Show("RUT ingresado es invalido");
                return;
            }
            else
            {
                lblMensajee.Text = ("");
            }
            

            // Capturar desde las cajas de textos los valores
            string ruut = txtRUT.Text;
            string dv = txtDV.Text;
            string nombree = txtNombre.Text;
            string apellidoo1 = txtApellido1.Text;
            string apellidoo2 = txtApellido2.Text;
            DateTime fecha = dateFecha.Value;
            string fechaa = fecha.ToString("yyyy-MM-dd");

            string PROFESIOON = boxProfesion.SelectedValue.ToString();
            //string profesioon = valueMember.int;
            string sueldoo = txtSueldo.Text;

            

            // Definir string de conexion y el comando sal

            // Autenticacion Windows
            //string strWindows = "server=DESKTOP-DEKF1IC;database=sistema_remuneracion;Integrated Security=True";
            // Autenticacion SQL Server
            string strConexionSQL = "Server=BGLABI00716\\BUSSQL;Database=simucredito;User Id=sa;Password=Aiep.2022;";

            // Instruccion SQL
            string comandoSQL = "insert cliente (RUT,DV,NOMBRE,APELLIDO1,APELLIDO2,FECHA_NAC,ID_PROF,SUELDO_LIQ) values ('" + ruut + "','" + dv + "','" + nombree + "','" + apellidoo1 + "','" + apellidoo2 + "','" + fechaa + "'," + PROFESIOON + "," + sueldoo + ")";

            // Crear los objetos para la conexion a la BD
            SqlDataAdapter da;
            SqlConnection con = new SqlConnection(strConexionSQL);
            try
            {
                // Abrir la conexion 
                con.Open();

                // Ejecutar la instrucicon SQL
                da = new SqlDataAdapter();
                da.InsertCommand = new SqlCommand(comandoSQL, con);
                da.InsertCommand.ExecuteNonQuery();

                // Cerra la conexion
                con.Close();

                // Actualizar la grilla
                ActualizarGrilla();

                // Mostrar mensaje de exito
                MessageBox.Show("Registro grabado exitosamente.");

            }
            catch (Exception ex)
            {
                // en caso de algun error, mostrar el error
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                    con.Close();
            }
            // Fin 

        }

        private void ActualizarGrilla()
        {
            try
            {
                // Poblar grilla
                string strConexionSQL = "Server=BGLABI00716\\BUSSQL;Database=simucredito;User Id=sa;Password=Aiep.2022;";
                string comandoSQL = "select * from cliente";
                SqlConnection con = new SqlConnection(strConexionSQL);
                DataTable tbTipo = new DataTable();

                // Abrir conexión y ejecutar instrucción SQL
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(comandoSQL, con);
                da.Fill(tbTipo);

                // Poblar la grilla con el resultado del select 
                dataGridView1.DataSource = tbTipo;

                // Cerrar la conexión
                con.Close();
            }
            catch (Exception es)
            {
                MessageBox.Show(es.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Inicio
            try
            {
                // Poblar combobox

                // Definir string de conexion y el comando sql

                
                // Autenticacion SQL Server
                string strConexionSQL = "Server=BGLABI00716\\BUSSQL;Database=simucredito;User Id=sa;Password=Aiep.2022;";

                // Instruccion SQL
                string comandoSQL = "select ID_PROF, NOMBRE_P  from profesion";


                // Crear los objetos para la conexion a la BD
                SqlConnection con = new SqlConnection(strConexionSQL);
                DataTable tbTipo = new DataTable();

                // abrir conexion y ejecutar instraucicon sql
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(comandoSQL, con);

                da.Fill(tbTipo);

                // configuracion del combox 
                boxProfesion.DisplayMember = "NOMBRE_P";
                boxProfesion.ValueMember = "ID_PROF";

                // poblar el combobox con el resultado del select 
                boxProfesion.DataSource = tbTipo;

                // cerra la conexion
                con.Close();
            }
            catch (Exception es)
            {
                MessageBox.Show(es.Message);
            }
            // Fin 


            // Inicio
            try
            {
                // Poblar grilla

                // Definir string de conexion y el comando sql

                
                // Autenticacion SQL Server
                string strConexionSQL = "Server=BGLABI00716\\BUSSQL;Database=simucredito;User Id=sa;Password=Aiep.2022;";

                // Instruccion SQL
                string comandoSQL = "select * from cliente";


                // Crear los objetos para la conexion a la BD
                SqlConnection con = new SqlConnection(strConexionSQL);
                DataTable tbTipo = new DataTable();

                // abrir conexion y ejecutar instrucicon sql
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(comandoSQL, con);

                da.Fill(tbTipo);



                // poblar el combobox con el resultado del select 
                dataGridView1.DataSource = tbTipo;

                // cerra la conexion
                con.Close();
            }
            catch (Exception es)
            {
                MessageBox.Show(es.Message);
            }
            // Fin
        }
    }
}
